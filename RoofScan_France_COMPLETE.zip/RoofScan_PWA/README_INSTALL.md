ROOFSCAN FRANCE — INSTALLATION

1. Décompresser RoofScan_PWA.zip.
2. Publier le contenu du dossier sur un hébergement HTTPS.
3. Ouvrir l’adresse dans Chrome sur Android.
4. Appuyer sur « Installer » ou ⋮ → Ajouter à l’écran d’accueil.

La version incluse utilise la Géoplateforme IGN : géocodage + BD TOPO bâtiment. Le champ matériau est affiché lorsqu’il est renseigné dans BD TOPO. Le calcul précis des pans/pentes/surfaces réelles par nuage LiDAR HD nécessite encore le moteur serveur de traitement LiDAR.

Sources : IGN Géoplateforme, BD TOPO, LiDAR HD.
